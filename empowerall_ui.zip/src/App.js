import React from 'react';
import './resources/styles.css';


import Header  from './components/Header';
import Footer from './components/Footer';

import Box from '@mui/material/Box';
import Upload from './components/Upload';

const App = () =>{
  return (
    <div className="App">
      <Header/>
{/* 
      <div style={{backgroundColor:'#21b2a6',height:'200px'}}></div> */}
      <Upload/>
      {/* <div style={{backgroundColor:'#505393',height:'800px'}}> </div>
      <div style={{backgroundColor:'green',height:'800px'}}></div> */}

      <Footer/>
    </div>
  );
}

export default App;
