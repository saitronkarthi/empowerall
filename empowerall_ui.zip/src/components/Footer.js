import React from 'react';
import { Fade } from 'react-awesome-reveal';

const Footer = () => {
    return (
        <footer className="bck_black">
            <Fade triggerOnce delay={500}>
                <div className="font_righteous footer_logo_venue">Hack DFW 2021</div>
                <div className="footer_copyright">
                 Akhil Karthi Meena
                </div>
            </Fade>
        </footer>
    )

}

export default Footer;