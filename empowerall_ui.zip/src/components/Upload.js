import React from 'react';
import { Backdrop, CircularProgress, Fab } from '@mui/material';
import UploadIcon from '@mui/icons-material/Upload';
import '../resources/styles.css';


const Upload = () => {
    const handleUploadClick = (event) => {
        console.log(event);
        console.log(event.target.files[0]);
        handleToggle();
        alert(event.target.files[0].name+"- Size "+event.target.files[0].size);

      };
      const [open, setOpen] = React.useState(false);
      const handleClose = () => {
        setOpen(false);
      };
      const handleToggle = () => {
        setOpen(!open);
      };
    return (

        <div className="container">

    
                <div className="upload">
{/* 
                    <label htmlFor="btn-upload" >
                        <input
                            id="btn-upload"
                            name="btn-upload"
                            style={{ display: 'none' }}
                            type="file"
                        //onChange={this.selectFile}
                        />
                        <Button
                            className="btn-choose"
                            variant="outlined"
                            component="span" >
                            Choose Files
                        </Button>
                    </label> */}
                </div>
                <div className="upload">
                    <label htmlFor="btn-upload">
                        <input
                            id="btn-upload"
                            name="btn-upload"
                            style={{ display: 'none' }}
                            type="file"
                            onChange={handleUploadClick}
                        />
                        <Fab component="span">
                            <UploadIcon />
                        </Fab>
                    </label>

                </div>

                <div className="header_logo_title">Upload Video</div>   
            <div className="embe">
                <div style={{float:"left",width:"45%", padding:"1%"}}>
                <div className="header_logo_title">Uploaded Video</div>                     
                    <iframe className="myFrame" src="https://www.youtube.com/embed/6M5VXKLf4D4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>

                <div style={{float:"right",width:"45%", padding:"1%"}}>
                <div className="header_logo_title">Translated Video</div>                     
                    <iframe className="myFrame" src="https://www.youtube.com/embed/6M5VXKLf4D4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
            
            <div>
            <Backdrop
                sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={open}
                onClick={handleClose}
            >
            <CircularProgress color="inherit" />
            </Backdrop>
        </div>

        </div>
    )

}


export default Upload;