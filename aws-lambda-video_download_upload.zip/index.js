const stream = require('stream');
const youtubedl = require('youtube-dl-exec');
const AWS = require('aws-sdk');

exports.handler = function(event, context, cb) {   
  const s3 = new AWS.S3({apiVersion: '2006-03-01'});
  const passthrough = new stream.PassThrough();
  const dl = youtubedl('https://www.youtube.com/watch?v=3XFODda6YXo', ['--format=best[ext=mp4]'], {maxBuffer: Infinity});
  dl.once('error', (err) => {
    cb(err);
  });
  const key = `${context.awsRequestId}.mp4`;
  const upload = new AWS.S3.ManagedUpload({
    params: {
      Bucket: 'vdado',
      Key: key,
      Body: passtrough
    },
    partSize: 1024 * 1024 * 64 // in bytes
  });

  upload.send((err) => {
    if (err) {
      cb(err);
    } else {
      cb(null, {
        bucketName: 'vdado',
        key,
        url: `s3://vdado/${key}`
      });
    }
  });
  dl.pipe(passthrough);
}
